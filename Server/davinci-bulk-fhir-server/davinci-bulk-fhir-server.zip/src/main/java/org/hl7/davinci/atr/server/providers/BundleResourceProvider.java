package org.hl7.davinci.atr.server.providers;

import org.hl7.davinci.atr.server.model.DafBundle;
import org.hl7.davinci.atr.server.service.BundleService;
import org.hl7.fhir.r4.model.Bundle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.jaxrs.server.AbstractJaxRsResourceProvider;
import ca.uhn.fhir.rest.annotation.Create;
import ca.uhn.fhir.rest.annotation.ResourceParam;
import ca.uhn.fhir.rest.annotation.Transaction;
import ca.uhn.fhir.rest.annotation.TransactionParam;
import ca.uhn.fhir.rest.api.MethodOutcome;

@Component
public class BundleResourceProvider extends AbstractJaxRsResourceProvider<Bundle> {

	private static final Logger logger = LoggerFactory.getLogger(BundleResourceProvider.class);    

    @Autowired
    BundleService service;
    public BundleResourceProvider(FhirContext fhirContext) {
        super(fhirContext);
    }
    
	@Override
	public Class<Bundle> getResourceType() {
		return Bundle.class;
	}
	
    /**
     * The create  operation saves a new resource to the server, 
     * allowing the server to give that resource an ID and version ID.
     * Create methods must be annotated with the @Create annotation, 
     * and have a single parameter annotated with the @ResourceParam annotation. 
     * This parameter contains the resource instance to be created. 
     * Create methods must return an object of type MethodOutcome . 
     * This object contains the identity of the created resource.
     * Example URL to invoke this method (this would be invoked using an HTTP POST, 
     * with the resource in the POST body): http://<server name>/<context>/fhir/Bundle
     * @param theBundle
     * @return
     */
	@Create
    public MethodOutcome createBundle(@ResourceParam Bundle theBundle) {
		MethodOutcome retVal = null;
    	try {
        	// Save this Bundle to the database...
    		System.out.println("In createBundle ");
        	DafBundle dafBundle = service.createBundle(theBundle);
        	retVal = new MethodOutcome();
    		//retVal.setId(new IdType(RESOURCE_TYPE, theBundle.getIdElement().getIdPart(), theBundle.getMeta().getVersionId()));    		
    	}
    	catch(Exception e) {
    		logger.error("Exception in createBundle of BundleResourceProvider ", e);
    	}
		return retVal;
    }
}
