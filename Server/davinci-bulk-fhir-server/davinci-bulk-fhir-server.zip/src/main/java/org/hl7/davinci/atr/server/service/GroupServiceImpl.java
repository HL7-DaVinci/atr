package org.hl7.davinci.atr.server.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.hl7.davinci.atr.server.constants.TextConstants;
import org.hl7.davinci.atr.server.dao.GroupDao;
import org.hl7.davinci.atr.server.model.DafGroup;
import org.hl7.davinci.atr.server.util.FhirUtility;
import org.hl7.davinci.atr.server.util.SearchParameterMap;
import org.hl7.fhir.r4.model.CodeType;
import org.hl7.fhir.r4.model.Coverage;
import org.hl7.fhir.r4.model.DateTimeType;
import org.hl7.fhir.r4.model.Extension;
import org.hl7.fhir.r4.model.Group;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.Group.GroupMemberComponent;
import org.hl7.fhir.r4.model.Parameters;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Period;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.PractitionerRole;
import org.hl7.fhir.r4.model.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.parser.IParser;
import ca.uhn.fhir.rest.server.exceptions.ResourceNotFoundException;
import ca.uhn.fhir.rest.server.exceptions.UnprocessableEntityException;

@Service("groupService")
@Transactional
public class GroupServiceImpl implements GroupService {
	
	public static final String RESOURCE_TYPE = "Group";
	private static final Logger logger = LoggerFactory.getLogger(GroupServiceImpl.class);  
	@Autowired
	private FhirContext fhirContext;
	
	@Autowired
    private GroupDao groupDao;
	
	@Autowired
	private PatientService patientService;
	
	@Autowired
	private PractitionerService practitionerService;
	
	@Autowired
	private PractitionerRoleService practitionerRoleService;
	
	@Autowired
	private OrganizationService organizationService;
	
	@Autowired
	private CoverageService coverageService;

	@Override
	public DafGroup updateGroupById(int id, Group theGroup) {
		return groupDao.updateGroupById(id, theGroup);
	}

	@Override
	public DafGroup createGroup(Group theGroup) {
		return groupDao.createGroup(theGroup);
	}

	@Override
	public DafGroup getGroupById(String id) {
		DafGroup dafGroup = null;
		try {
			dafGroup = groupDao.getGroupById(id);
//			IParser jsonParser = fhirContext.newJsonParser();
//			if(dafGroup != null) {
//				group = jsonParser.parseResource(Group.class, dafGroup.getData());
//			}
		}
		catch(Exception e) {
			logger.error("Exception in getGroupById of GroupServiceImpl ", e);
		}
		return dafGroup;
	}

	@Override
	public List<Group> search(SearchParameterMap paramMap) {
		Group group = null;
		List<Group> groupList = new ArrayList<>();
		try {
			IParser jsonParser = fhirContext.newJsonParser();
			List<DafGroup> dafGroupList = groupDao.search(paramMap);
			if(dafGroupList != null && !dafGroupList.isEmpty()) {
				for(DafGroup dafGroup : dafGroupList) {
					group = jsonParser.parseResource(Group.class, dafGroup.getData());
					String str = fhirContext.newJsonParser().encodeResourceToString(group);
					System.out.println("GROUP IN STRING :: \n"+str);
					group.setId(group.getId());
					groupList.add(group);
				}
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return groupList;
	}

	@Override
	public DafGroup addMemberToGroup(Group group, DafGroup dafGroup, String patientMemberId, String providerId, String providerReferenceResource, String coverageId, Period attributionPeriod) {
		DafGroup updatedDafGroup = null;
		try {
			List<GroupMemberComponent> memberList = new ArrayList<>();
			boolean isMemberPatientFound = false;
			boolean isAttributionCoverageFound = false;
			if(group.hasMember()) {
				memberList = group.getMember();
				for (GroupMemberComponent memberGroup : new ArrayList<GroupMemberComponent>(memberList)) {
					//GroupMemberComponent memberGroup = iterator.next();
					if(memberGroup.hasEntity() && memberGroup.getEntity().hasReferenceElement()) {
						String entityId = memberGroup.getEntity().getReferenceElement().getIdPart();
						if(patientMemberId.equalsIgnoreCase(entityId)) {
							isMemberPatientFound = true;
							if(StringUtils.isNotBlank(coverageId)) {
								isAttributionCoverageFound = updateGroupMemberComponentCoverageReferenceExtension(memberGroup, coverageId, isAttributionCoverageFound);
							}
							if(StringUtils.isNotBlank(providerId) && StringUtils.isNotBlank(providerReferenceResource)) {
								updateGroupMemberComponentProviderReferenceExtension(memberGroup, providerId, providerReferenceResource, isAttributionCoverageFound);
							}
							logger.info(" :: Updating existing patient entity extension :: ");
							break;
						} 
					}
				}
				if(!isMemberPatientFound) {
					GroupMemberComponent theGroupMemberComponent = FhirUtility.getGroupMemberComponent(patientMemberId, providerId, providerReferenceResource, coverageId, attributionPeriod);
					if(theGroupMemberComponent != null) {
						memberList.add(theGroupMemberComponent);
						logger.info(" :: Adding one new GroupMemberComponent :: ");
						group.setMember(memberList);
					}
				}
			}
			else {
				List<GroupMemberComponent> newGroupMemberComponentList = null;
				GroupMemberComponent newGroupMemberComponent = FhirUtility.getGroupMemberComponent(patientMemberId, providerId, providerReferenceResource, coverageId, attributionPeriod);
				if(newGroupMemberComponent != null && !newGroupMemberComponent.isEmpty()) {
					newGroupMemberComponentList = new ArrayList<>();
					newGroupMemberComponentList.add(newGroupMemberComponent);
					logger.info(" :: Adding new Member for first time for group :: ");
					group.setMember(newGroupMemberComponentList);
				}
			}
			updatedDafGroup = groupDao.updateGroupById(dafGroup.getId(), group);
			String str = fhirContext.newJsonParser().encodeResourceToString(group);
			System.out.println("GROUP IN STRING :: \n"+str);
		}
		catch(Exception e) {
			logger.error("Exception in addMemberToGroup of GroupServiceImpl ", e);
		}
		return updatedDafGroup;
	}

	/**
	 * updateGroupMemberComponentChangeTypeExtension
	 * @param memberGroup
	 */
	private void updateGroupMemberComponentChangeTypeExtension(GroupMemberComponent memberGroup, String changeCode) {
		try {
			if(StringUtils.isNotBlank(changeCode)) {
				if (memberGroup.hasExtension(TextConstants.MEMBER_CHANGETYPE_SYSTEM)) {
					CodeType codeType = FhirUtility.getCodeType(changeCode);
					memberGroup.getExtensionByUrl(TextConstants.MEMBER_CHANGETYPE_SYSTEM).setValue(codeType);
				}
				else {
					if(memberGroup.hasExtension()) {
						List<Extension> extensionList = memberGroup.getExtension();
						Extension codeExtension = FhirUtility.getExtensionForCodeType(changeCode);
						if(codeExtension != null && !codeExtension.isEmpty()) {
							extensionList.add(codeExtension);
						}
					}
				}
			}
		}
		catch(Exception e) {
			logger.error("Exception in updateGroupMemberComponentChangeTypeExtension of GroupServiceImpl ", e);
		}
	}
	
	/**
	 * updateGroupMemberComponentCoverageReferenceExtension
	 * @param memberGroup
	 * @param coverageId
	 */
	private boolean updateGroupMemberComponentCoverageReferenceExtension(GroupMemberComponent memberGroup, String coverageId, boolean isAttributionCoverageFound) {
		try {
			if(StringUtils.isNotBlank(coverageId)) {
				if (memberGroup.hasExtension(TextConstants.MEMBER_COVERAGE_SYSTEM)) {
					if(memberGroup.getExtensionByUrl(TextConstants.MEMBER_COVERAGE_SYSTEM).hasValue()) {
						Reference reference = (Reference) memberGroup.getExtensionByUrl(TextConstants.MEMBER_COVERAGE_SYSTEM).getValue();
						if(!coverageId.equalsIgnoreCase(reference.getReferenceElement().getIdPart())) {
							Reference coverageReference = FhirUtility.getReference(coverageId, "Coverage");
							memberGroup.getExtensionByUrl(TextConstants.MEMBER_COVERAGE_SYSTEM).setValue(coverageReference);
							updateGroupMemberComponentChangeTypeExtension(memberGroup, TextConstants.CHANGE_TYPE);
							isAttributionCoverageFound = true;
						}
						else {
							updateGroupMemberComponentChangeTypeExtension(memberGroup, TextConstants.NOCHANGE_TYPE);
							logger.info(" Coverage nochange ");
							isAttributionCoverageFound = false;
						}
					}
					else {
						Reference coverageReference = FhirUtility.getReference(coverageId, "Coverage");
						memberGroup.getExtensionByUrl(TextConstants.MEMBER_COVERAGE_SYSTEM).setValue(coverageReference);
						updateGroupMemberComponentChangeTypeExtension(memberGroup, TextConstants.CHANGE_TYPE);
						isAttributionCoverageFound = true;
					}
				}
				else {
					if(memberGroup.hasExtension()) {
						List<Extension> extensionList = memberGroup.getExtension();
						Extension coverageExtension = FhirUtility.getExtensionForReference(coverageId, "Coverage", TextConstants.MEMBER_COVERAGE_SYSTEM);
						if(coverageExtension != null && !coverageExtension.isEmpty()) {
							extensionList.add(coverageExtension);
							updateGroupMemberComponentChangeTypeExtension(memberGroup, TextConstants.CHANGE_TYPE);
							isAttributionCoverageFound = true;
						}
					}
				}
			}
		}
		catch(Exception e) {
			logger.error("Exception in updateGroupMemberComponentCoverageReferenceExtension of GroupServiceImpl ", e);
		}
		return isAttributionCoverageFound;
	}
	
	/**
	 * updateGroupMemberComponentProviderReferenceExtension
	 * @param memberGroup
	 * @param providerId
	 * @param providerReferenceResource
	 */
	private void updateGroupMemberComponentProviderReferenceExtension(GroupMemberComponent memberGroup, String providerId, String providerReferenceResource, boolean isAttributionCoverageFound) {
		try {
			if(StringUtils.isNotBlank(providerId) && StringUtils.isNotBlank(providerReferenceResource)) {
				if (memberGroup.hasExtension(TextConstants.MEMBER_PROVIDER_SYSTEM)) {
					if(memberGroup.getExtensionByUrl(TextConstants.MEMBER_PROVIDER_SYSTEM).hasValue()) {
						Reference reference = (Reference) memberGroup.getExtensionByUrl(TextConstants.MEMBER_PROVIDER_SYSTEM).getValue();
						if(!providerId.equalsIgnoreCase(reference.getReferenceElement().getIdPart())) {
							Reference coverageReference = FhirUtility.getReference(providerId, providerReferenceResource);
							memberGroup.getExtensionByUrl(TextConstants.MEMBER_PROVIDER_SYSTEM).setValue(coverageReference);
							updateGroupMemberComponentChangeTypeExtension(memberGroup, TextConstants.CHANGE_TYPE);
						}
						else {
							logger.info(" isAttributionCoverageFound "+isAttributionCoverageFound);
							if(!isAttributionCoverageFound) {
								updateGroupMemberComponentChangeTypeExtension(memberGroup, TextConstants.NOCHANGE_TYPE);
								logger.info(" Provider nochange ");
							}
						}
					}
					else {
						Reference coverageReference = FhirUtility.getReference(providerId, providerReferenceResource);
						memberGroup.getExtensionByUrl(TextConstants.MEMBER_PROVIDER_SYSTEM).setValue(coverageReference);
						updateGroupMemberComponentChangeTypeExtension(memberGroup, TextConstants.CHANGE_TYPE);
					}
				}
				else {
					if(memberGroup.hasExtension()) {
						List<Extension> extensionList = memberGroup.getExtension();
						Extension coverageExtension = FhirUtility.getExtensionForReference(providerId, providerReferenceResource, TextConstants.MEMBER_PROVIDER_SYSTEM);
						if(coverageExtension != null && !coverageExtension.isEmpty()) {
							extensionList.add(coverageExtension);
							updateGroupMemberComponentChangeTypeExtension(memberGroup, TextConstants.CHANGE_TYPE);
						}
					}
				}
			}
		}
		catch(Exception e) {
			logger.error("Exception in updateGroupMemberComponentProviderReferenceExtension of GroupServiceImpl ", e);
		}
	}

	@Override
	public DafGroup removeMemberFromGroup(Group group, DafGroup dafGroup, String patientMemberId,
			String providerId, String providerReferenceResource, String coverageId,
			Period attributionPeriod) throws Exception{
		DafGroup updatedDafGroup = null;
			List<GroupMemberComponent> memberList = new ArrayList<>();
			boolean isGroupMemberRemoved = false;
			if(group.hasMember()) {
				memberList = group.getMember();
				for (GroupMemberComponent memberGroup : new ArrayList<GroupMemberComponent>(memberList)) {
					//GroupMemberComponent memberGroup = iterator.next();
					if(memberGroup.hasEntity() && memberGroup.getEntity().hasReferenceElement()) {
						String entityId = memberGroup.getEntity().getReferenceElement().getIdPart();
						if(patientMemberId.equalsIgnoreCase(entityId)) {
							if(StringUtils.isNotBlank(providerId) && StringUtils.isNotBlank(providerReferenceResource)) {
								if (memberGroup.hasExtension(TextConstants.MEMBER_PROVIDER_SYSTEM)) {
									if(memberGroup.getExtensionByUrl(TextConstants.MEMBER_PROVIDER_SYSTEM).hasValue()) {
										Reference reference = (Reference) memberGroup.getExtensionByUrl(TextConstants.MEMBER_PROVIDER_SYSTEM).getValue();
										if(providerId.equalsIgnoreCase(reference.getReferenceElement().getIdPart())
												&& providerReferenceResource.equalsIgnoreCase(reference.getReferenceElement().getResourceType())) {
											if(StringUtils.isNotBlank(coverageId)) {
												if (memberGroup.hasExtension(TextConstants.MEMBER_COVERAGE_SYSTEM)) {
													if(memberGroup.getExtensionByUrl(TextConstants.MEMBER_COVERAGE_SYSTEM).hasValue()) {
														Reference coverageReference = (Reference) memberGroup.getExtensionByUrl(TextConstants.MEMBER_COVERAGE_SYSTEM).getValue();
														if(coverageId.equalsIgnoreCase(coverageReference.getReferenceElement().getIdPart())) {
															memberList.remove(memberGroup);
															isGroupMemberRemoved = true;
															logger.info(" Removing member from Group.member for memberId+providerNpi+attributionPeriod / "
																	+ "patientReference+providerReference+attributionPeriod. patientMemberId: "+patientMemberId+" providerId: "+providerId+
																	" coverageId : "+coverageId);	
														}
														else {
															throw new ResourceNotFoundException(" No coverage found for given attributionPeriod  "+coverageId);	
														}
													}
												}
											}
											else {
												memberList.remove(memberGroup);
												isGroupMemberRemoved= true;
												logger.info(" Removing member from Group.member for memberId+providerNpi / "
														+ "patientReference+providerReference. patientMemberId: "+patientMemberId+" providerId: "+providerId);	
											}
										}
										else {
											throw new ResourceNotFoundException(" No provider found for given provider "+providerId);	
										}
									}
								}
							}
							else {
								memberList.remove(memberGroup);
								isGroupMemberRemoved = true;
								logger.info(" Removing member from Group.member for memberId/patientReference. patientMemberId : "+patientMemberId);	
							}
							break;
						} 
					}
				}
			}
			else {
				logger.error(" :: Group doesn't have any members ");
			}
			if(isGroupMemberRemoved) {
				updatedDafGroup = groupDao.updateGroupById(dafGroup.getId(), group);
				logger.info(" updated the group successfully ");
			}
			else {
  			  	throw new UnprocessableEntityException("Group doesn't contain given memberId/patientReference");
			}
			String str = fhirContext.newJsonParser().encodeResourceToString(group);
			System.out.println("GROUP IN STRING :: \n"+str);
		return updatedDafGroup;
	}

	@Override
	public DafGroup processAddMemberToGroup(Parameters theParameters,String groupId) {
		String patientMemberId = null;
		String attributeProviderId = null;
		String attributeProviderReferenceResource = null;
		String coverageReference = null;
		DafGroup updatedDafGroup = null;
		Period attributionPeriod = null;
		Group group = null;
		DafGroup dafGroup = getGroupById(groupId);
		if (dafGroup != null && StringUtils.isNotBlank(dafGroup.getData())) {
			group = parseGroup(dafGroup.getData());
			if (group != null && !group.isEmpty() && theParameters != null && !theParameters.isEmpty()) {
				if (theParameters.getParameter(TextConstants.MEMBER_ID) != null
						&& theParameters.getParameter(TextConstants.PROVIDER_NPI) != null) {
					Identifier memberId = (Identifier) theParameters.getParameter(TextConstants.MEMBER_ID);
					Identifier providerNpi = (Identifier) theParameters.getParameter(TextConstants.PROVIDER_NPI);
					attributionPeriod = (Period) theParameters.getParameter(TextConstants.ATTRIBUTION_PERIOD);
					logger.info(" memberId is " + memberId.getValue());
					logger.info(" providerNpi is " + providerNpi.getValue());
					logger.info(" Group id " + group.getId());
					Patient patient = patientService.getPatientByMemeberId(memberId.getSystem(),
							memberId.getValue());
					if (patient != null) {
						patientMemberId = patient.getIdElement().getIdPart();
						Practitioner practitioner = practitionerService
								.getPractitionerByProviderNpi(providerNpi.getSystem(), providerNpi.getValue());
						if (practitioner == null) {
							PractitionerRole practitionerRole = practitionerRoleService
									.getPractitionerRoleByProviderNpi(providerNpi.getValue());
							if (practitionerRole == null) {
								Organization organization = organizationService
										.getOrganizationByProviderNpi(providerNpi.getValue());
								if (organization != null) {
									attributeProviderId = organization.getIdElement().getIdPart();
									attributeProviderReferenceResource = "Organization";
								} else {
									throw new ResourceNotFoundException(
											"Couldn't find any Provider with providerNpi : "
													+ providerNpi.getValue());
								}
							} else {
								attributeProviderId = practitionerRole.getIdElement().getIdPart();
								attributeProviderReferenceResource = "PractitionerRole";
							}
						} else {
							attributeProviderId = practitioner.getIdElement().getIdPart();
							attributeProviderReferenceResource = "Practitioner";
						}
					} else {
						throw new ResourceNotFoundException(
								"Couldn't find any Patient with member id : " + memberId.getValue());
					}
				} else {
					if (theParameters.getParameter(TextConstants.PATIENT_REFERENCE) != null
							&& theParameters.getParameter(TextConstants.PROVIDER_REFERENCE) != null) {
						Reference patientId = (Reference) theParameters
								.getParameter(TextConstants.PATIENT_REFERENCE);
						Reference providerId = (Reference) theParameters
								.getParameter(TextConstants.PROVIDER_REFERENCE);
						attributionPeriod = (Period) theParameters.getParameter(TextConstants.ATTRIBUTION_PERIOD);
						logger.info(" patientId is " + patientId.getReferenceElement().getIdPart());
						logger.info(" providerId is " + providerId.getReferenceElement().getIdPart());
						logger.info(" Group id " + group.getId());
						String providerReferenceResource = providerId.getReferenceElement().getResourceType();
						logger.info(" providerReferenceResource " + providerReferenceResource);
						Patient patient = patientService
								.getPatientById(patientId.getReferenceElement().getIdPart());
						if (patient != null) {
							patientMemberId = patient.getIdElement().getIdPart();
							if (StringUtils.isNotBlank(providerReferenceResource)
									&& providerReferenceResource.equalsIgnoreCase("Practitioner")) {
								Practitioner practitioner = practitionerService
										.getPractitionerById(providerId.getReferenceElement().getIdPart());
								if (practitioner != null && !practitioner.isEmpty()) {
									attributeProviderId = practitioner.getIdElement().getIdPart();
									attributeProviderReferenceResource = "Practitioner";
								} else {
									throw new ResourceNotFoundException(
											"Couldn't find any Practitioner with reference id : "
													+ attributeProviderId);
								}
							} else if (StringUtils.isNotBlank(providerReferenceResource)
									&& providerReferenceResource.equalsIgnoreCase("PractitionerRole")) {
								PractitionerRole practitionerRole = practitionerRoleService
										.getPractitionerRoleById(providerId.getReferenceElement().getIdPart());
								if (practitionerRole != null && !practitionerRole.isEmpty()) {
									attributeProviderId = practitionerRole.getIdElement().getIdPart();
									attributeProviderReferenceResource = "PractitionerRole";
								} else {
									throw new ResourceNotFoundException(
											"Couldn't find any PractitionerRole with reference id : "
													+ attributeProviderId);
								}
							} else if (StringUtils.isNotBlank(providerReferenceResource)
									&& providerReferenceResource.equalsIgnoreCase("Organization")) {
								Organization organization = organizationService
										.getOrganizationById(providerId.getReferenceElement().getIdPart());
								if (organization != null && !organization.isEmpty()) {
									attributeProviderId = organization.getIdElement().getIdPart();
									attributeProviderReferenceResource = "Organization";
								} else {
									throw new ResourceNotFoundException(
											"Couldn't find any Organization with reference id : "
													+ attributeProviderId);
								}
							}
						} else {
							throw new ResourceNotFoundException(
									"Couldn't find any Patient with reference id : " + patientMemberId);
						}
					} else {
						throw new UnprocessableEntityException(
								"Please provide MemberId + ProviderNPI or patientReference + providerReference to $member-add.");
					}
				}
				if (attributionPeriod != null) {
					DateTimeType startDate = attributionPeriod.getStartElement();
					DateTimeType endDate = attributionPeriod.getEndElement();
					logger.info("  startDate	" + startDate);
					logger.info(" endDate	" + endDate);
					Coverage coverage = coverageService.getCoverageByPeriodAndMemeberId(attributionPeriod,
							patientMemberId);
					if (coverage != null) {
						coverageReference = coverage.getIdElement().getIdPart();
					} else {
						throw new ResourceNotFoundException(
								"No coverage found for given attribution period start : " + startDate.getValue()
										+ " end: " + endDate.getValue() + "and for patient reference id "
										+ patientMemberId);
					}
				}
				if (StringUtils.isNotBlank(patientMemberId) && StringUtils.isNotBlank(attributeProviderId)) {
					updatedDafGroup = addMemberToGroup(group, dafGroup, patientMemberId,
							attributeProviderId, attributeProviderReferenceResource, coverageReference,
							attributionPeriod);
					
				} else {
					throw new ResourceNotFoundException(
							"No patient found " + patientMemberId + " No providers found " + attributeProviderId);
				}
			} else {
				throw new UnprocessableEntityException("No Parameters/Group found!");
			}
		} else {
			throw new ResourceNotFoundException(" Gorup not found " + groupId);
		}
		return updatedDafGroup;
	}
	
	private Group parseGroup(String data) {
		Group group = null;
		try {
			if (StringUtils.isNotBlank(data)) {
				IParser jsonParser = fhirContext.newJsonParser();
				group = jsonParser.parseResource(Group.class, data);
			}
		} catch (Exception e) {
			logger.error("Exception in parseGroup of GroupResourceProvider ", e);
		}
		return group;
	}

	@Override
	public DafGroup processRemoveMemberToGroup(Parameters theParameters, String groupId) {
		String patientMemberId = null;
		String attributeProviderId = null;
		String attributeProviderReferenceResource = null;
		String coverageReference = null;
		DafGroup updatedDafGroup = null;
		Period attributionPeriod = null;
		Group group = null;
		DafGroup dafGroup = getGroupById(groupId);
		if (dafGroup != null && StringUtils.isNotBlank(dafGroup.getData())) {
			group = parseGroup(dafGroup.getData());
			if (group != null && !group.isEmpty() && theParameters != null && !theParameters.isEmpty()) {
				if (theParameters.getParameter(TextConstants.MEMBER_ID) != null) {
					Identifier memberId = (Identifier) theParameters.getParameter(TextConstants.MEMBER_ID);
					Identifier providerNpi = new Identifier();
					if (theParameters.getParameter(TextConstants.PROVIDER_NPI) != null) {
						providerNpi = (Identifier) theParameters.getParameter(TextConstants.PROVIDER_NPI);
					}
					if (theParameters.getParameter(TextConstants.ATTRIBUTION_PERIOD) != null) {
						attributionPeriod = (Period) theParameters.getParameter(TextConstants.ATTRIBUTION_PERIOD);
					}
					logger.info(" memberId is " + memberId.getValue());
					logger.info(" providerNpi is " + providerNpi.getValue());
					logger.info(" Group id " + group.getId());
					Patient patient = patientService.getPatientByMemeberId(memberId.getSystem(),
							memberId.getValue());
					if (patient != null) {
						patientMemberId = patient.getIdElement().getIdPart();
						Practitioner practitioner = practitionerService
								.getPractitionerByProviderNpi(providerNpi.getSystem(), providerNpi.getValue());
						if (practitioner == null) {
							PractitionerRole practitionerRole = practitionerRoleService
									.getPractitionerRoleByProviderNpi(providerNpi.getValue());
							if (practitionerRole == null) {
								Organization organization = organizationService
										.getOrganizationByProviderNpi(providerNpi.getValue());
								if (organization != null) {
									attributeProviderId = organization.getIdElement().getIdPart();
									attributeProviderReferenceResource = "Organization";
								} else {
									throw new ResourceNotFoundException(
											"Couldn't find any Provider with providerNpi : "
													+ providerNpi.getValue());
								}
							} else {
								attributeProviderId = practitionerRole.getIdElement().getIdPart();
								attributeProviderReferenceResource = "PractitionerRole";
							}
						} else {
							attributeProviderId = practitioner.getIdElement().getIdPart();
							attributeProviderReferenceResource = "Practitioner";
						}
					} else {
						throw new ResourceNotFoundException(
								"Couldn't find any Patient with member id : " + memberId.getValue());
					}
				} else {
					if (theParameters.getParameter(TextConstants.PATIENT_REFERENCE) != null) {
						Reference patientId = (Reference) theParameters
								.getParameter(TextConstants.PATIENT_REFERENCE);
						Reference providerId = new Reference();
						if (theParameters.getParameter(TextConstants.PROVIDER_REFERENCE) != null) {
							providerId = (Reference) theParameters.getParameter(TextConstants.PROVIDER_REFERENCE);
						}
						if (theParameters.getParameter(TextConstants.ATTRIBUTION_PERIOD) != null) {
							attributionPeriod = (Period) theParameters
									.getParameter(TextConstants.ATTRIBUTION_PERIOD);
						}
						logger.info(" patientId is " + patientId.getReferenceElement().getIdPart());
						logger.info(" providerId is " + providerId.getReferenceElement().getIdPart());
						logger.info(" Group id " + group.getId());
						String providerReferenceResource = providerId.getReferenceElement().getResourceType();
						logger.info(" providerReferenceResource " + providerReferenceResource);
						Patient patient = patientService
								.getPatientById(patientId.getReferenceElement().getIdPart());
						if (patient != null) {
							patientMemberId = patient.getIdElement().getIdPart();
							if (StringUtils.isNotBlank(providerReferenceResource)
									&& providerReferenceResource.equalsIgnoreCase("Practitioner")) {
								Practitioner practitioner = practitionerService
										.getPractitionerById(providerId.getReferenceElement().getIdPart());
								if (practitioner != null && !practitioner.isEmpty()) {
									attributeProviderId = practitioner.getIdElement().getIdPart();
									attributeProviderReferenceResource = "Practitioner";
								} else {
									throw new ResourceNotFoundException(
											"Couldn't find any Practitioner with reference id ");
								}
							} else if (StringUtils.isNotBlank(providerReferenceResource)
									&& providerReferenceResource.equalsIgnoreCase("PractitionerRole")) {
								PractitionerRole practitionerRole = practitionerRoleService
										.getPractitionerRoleById(providerId.getReferenceElement().getIdPart());
								if (practitionerRole != null && !practitionerRole.isEmpty()) {
									attributeProviderId = practitionerRole.getIdElement().getIdPart();
									attributeProviderReferenceResource = "PractitionerRole";
								} else {
									throw new ResourceNotFoundException(
											"Couldn't find any PractitionerRole with reference id ");
								}
							} else if (StringUtils.isNotBlank(providerReferenceResource)
									&& providerReferenceResource.equalsIgnoreCase("Organization")) {
								Organization organization = organizationService
										.getOrganizationById(providerId.getReferenceElement().getIdPart());
								if (organization != null && !organization.isEmpty()) {
									attributeProviderId = organization.getIdElement().getIdPart();
									attributeProviderReferenceResource = "Organization";
								} else {
									throw new ResourceNotFoundException(
											"Couldn't find any Organization with reference id ");
								}
							}
						} else {
							throw new ResourceNotFoundException("Couldn't find any Patient with reference id ");
						}
					} else {
						throw new UnprocessableEntityException(
								"Please provide MemberId + ProviderNPI or patientReference + providerReference to $member-add.");
					}
				}
				if (attributionPeriod != null) {
					DateTimeType startDate = attributionPeriod.getStartElement();
					DateTimeType endDate = attributionPeriod.getEndElement();
					logger.info("  startDate	" + startDate);
					logger.info(" endDate	" + endDate);
					Coverage coverage = coverageService.getCoverageByPeriodAndMemeberId(attributionPeriod,
							patientMemberId);
					if (coverage != null) {
						coverageReference = coverage.getIdElement().getIdPart();
					} else {
						throw new ResourceNotFoundException(
								"No coverage found for given attribution period start : " + startDate.getValue()
										+ " end: " + endDate.getValue() + "and for patient reference id "
										+ patientMemberId);
					}
				}
				if (StringUtils.isNotBlank(patientMemberId)) {
					logger.info("patientMemberId :: " + patientMemberId);
					logger.info("attributeProviderId :: " + attributeProviderId);
					logger.info("attributeProviderReferenceResource :: " + attributeProviderReferenceResource);
					logger.info("coverageReference :: " + coverageReference);
					try {
						updatedDafGroup = removeMemberFromGroup(group, dafGroup, patientMemberId,
								attributeProviderId, attributeProviderReferenceResource, coverageReference,
								attributionPeriod);
					}catch(Exception e) {
						logger.error("Error in Removing the Member from Group::::{}",e.getMessage());
					}
				} else {
					throw new ResourceNotFoundException(
							"No patient found " + patientMemberId + " No providers found " + attributeProviderId);
				}
			} else {
				throw new UnprocessableEntityException("No Parameters/Group found!");
			}
		} else {
			throw new ResourceNotFoundException(" Gorup not found " + groupId);
		}
		return updatedDafGroup;
	}
}