package org.hl7.davinci.atr.server.dao;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.model.api.IQueryParameterType;
import ca.uhn.fhir.parser.IParser;
import ca.uhn.fhir.rest.param.DateParam;
import ca.uhn.fhir.rest.param.ReferenceParam;
import ca.uhn.fhir.rest.param.StringParam;
import ca.uhn.fhir.rest.param.TokenParam;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Restrictions;
import org.hl7.davinci.atr.server.model.DafDocumentReference;
import org.hl7.davinci.atr.server.util.SearchParameterMap;
import org.hl7.fhir.r4.model.DocumentReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

@Repository("DocumentReferenceDao")
public class DocumentReferenceDaoImpl extends AbstractDao implements DocumentReferenceDao {

	@Autowired
    private SessionFactory sessionFactory;
	
	@Autowired
	private FhirContext fhirContext;
	
	/**
	 * This method builds criteria for fetching DocumentReference record by id.
	 * 
	 * @param id : ID of the resource
	 * @return : DAF object of the DocumentReference
	 */
	public DafDocumentReference getDocumentReferenceById(int id) {	
		List<DafDocumentReference> list = getSession().createNativeQuery(
				"select * from documentreference where data->>'id' = '"+id+"' order by data->'meta'->>'versionId' desc", DafDocumentReference.class)
					.getResultList();
		return list.get(0);
	}

	/**
	 * This method builds criteria for fetching particular version of the
	 * DocumentReference record by id.
	 * 
	 * @param theId     : ID of the DocumentReference
	 * @param versionId : version of the DocumentReference record
	 * @return : DAF object of the DocumentReference
	 */
	public DafDocumentReference getDocumentReferenceByVersionId(int theId, String versionId) {
		DafDocumentReference list = getSession().createNativeQuery(
			"select * from documentreference where data->>'id' = '"+theId+"' and data->'meta'->>'versionId' = '"+versionId+"'", DafDocumentReference.class)
				.getSingleResult();
			return list;
	}

	/**
	 * This method invokes various methods for search
	 * 
	 * @param theMap : parameter for search
	 * @return criteria : DAF DocumentReference object
	 */
	@SuppressWarnings("unchecked")
	public List<DafDocumentReference> search(SearchParameterMap theMap) {
		@SuppressWarnings("deprecation")
		Criteria criteria = getSession().createCriteria(DafDocumentReference.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		// build criteria for id
		buildIdCriteria(theMap, criteria);

		// build criteria for identifier
		buildIdentifierCriteria(theMap, criteria);

		// build criteria for date
		buildDateCriteria(theMap, criteria);

		// build criteria for Type
		buildTypeCriteria(theMap, criteria);

		// build criteria for patient
		buildPatientCriteria(theMap, criteria);

		// build criteria for category
		buildCategoryCriteria(theMap, criteria);
		
		// build criteria for category
		buildStatusCriteria(theMap, criteria);
				
		// build criteria for category
		buildPeriodCriteria(theMap, criteria);
		
		return criteria.list();
	}

	/**
	 * This method builds criteria for Period
	 * 
	 * @param searchParameterMap : search parameter "Period"
	 * @param criteria           : for retrieving entities by composing Criterion
	 *                           objects
	 */
	private void buildPeriodCriteria(SearchParameterMap theMap, Criteria criteria) {
		 List<List<? extends IQueryParameterType>> list = theMap.get("period");
	        if (list != null) {
	            for (List<? extends IQueryParameterType> values : list) {
	            	Disjunction disjunction = Restrictions.disjunction();
	                for (IQueryParameterType params : values) {
	                    DateParam date = (DateParam) params;
	                    String dateFormat = date.getValueAsString();
	                    Criterion orCond= null;
	                    if(date.getPrefix() != null) {
	                        if(date.getPrefix().getValue() == "gt"){
	                        	orCond = Restrictions.or(
	                        				Restrictions.sqlRestriction("{alias}.data->'period'->>'start' > '"+dateFormat+ "'"),
	                        				Restrictions.sqlRestriction("{alias}.data->'period'->>'end' > '"+dateFormat+ "'")
	                        			);
	                        }else if(date.getPrefix().getValue() == "lt"){
	                        	orCond = Restrictions.or(
	                        				Restrictions.sqlRestriction("{alias}.data->'period'->>'start' < '"+dateFormat+ "'"),
	                        				Restrictions.sqlRestriction("{alias}.data->'period'->>'end' < '"+dateFormat+ "'")
	                        			);
	                        }else if(date.getPrefix().getValue() == "ge"){
	                        	orCond = Restrictions.or(
	                        				Restrictions.sqlRestriction("{alias}.data->'period'->>'start' >= '"+dateFormat+ "'"),
	                        				Restrictions.sqlRestriction("{alias}.data->'period'->>'end' >= '"+dateFormat+ "'")
	                        			);
	                        }else if(date.getPrefix().getValue() == "le"){
	                        	orCond = Restrictions.or(
		                        			Restrictions.sqlRestriction("{alias}.data->'period'->>'start' <= '"+dateFormat+ "'"),
		                        			Restrictions.sqlRestriction("{alias}.data->'period'->>'end' <= '"+dateFormat+ "'")
	                        			);
	                        }else {
	                        	orCond = Restrictions.or(
	                        				Restrictions.sqlRestriction("{alias}.data->'period'->>'start' = '"+dateFormat+"'"),
	                        				Restrictions.sqlRestriction("{alias}.data->'period'->>'end' = '"+dateFormat+"'")
	                        			);
	                        }
	                        disjunction.add(orCond);
	                     }
	                }
	                criteria.add(disjunction);
	            }
	        }
	}

	/**
	 * This method builds criteria for Status
	 * 
	 * @param searchParameterMap : search parameter "status"
	 * @param criteria           : for retrieving entities by composing Criterion
	 *                           objects
	 */
	private void buildStatusCriteria(SearchParameterMap theMap, Criteria criteria) {
			List<List<? extends IQueryParameterType>> list = theMap.get("status");
			if (list != null) {
				for (List<? extends IQueryParameterType> values : list) {
					for (IQueryParameterType params : values) {
						TokenParam status = (TokenParam) params;
						if (!status.isEmpty()) {
							criteria.add(Restrictions
									.sqlRestriction("{alias}.data->>'status' ilike '%" + status.getValue() + "%'"));
						} else if (status.getMissing()) {
							criteria.add(Restrictions.sqlRestriction("{alias}.data->>'status' IS NULL"));

						} else if (!status.getMissing()) {
							criteria.add(Restrictions.sqlRestriction("{alias}.data->>'status' IS NOT NULL"));

						}
					}
				}
			}
		}		
	

	/**
	 * This method builds criteria for type
	 * 
	 * @param searchParameterMap : search parameter "type"
	 * @param criteria           : for retrieving entities by composing Criterion
	 *                           objects
	 */
	private void buildTypeCriteria(SearchParameterMap theMap, Criteria criteria) {
		List<List<? extends IQueryParameterType>> list = theMap.get("type");
		if (list != null) {
			for (List<? extends IQueryParameterType> values : list) {
				Disjunction disjunction = Restrictions.disjunction();
				for (IQueryParameterType params : values) {
					TokenParam type = (TokenParam) params;
					Criterion criterion = null;
					if (!type.isEmpty()) {
						criterion = Restrictions.or(
									Restrictions.sqlRestriction("{alias}.data->'type'->'coding'->0->>'system' ilike '%"
											+ type.getValue() + "%'"),
									Restrictions.sqlRestriction("{alias}.data->'type'->'coding'->0->>'code' ilike '%"
											+ type.getValue() + "%'"),
									Restrictions.sqlRestriction("{alias}.data->'type'->'coding'->0->>'display' ilike '%"
											+ type.getValue() + "%'"),
									
									Restrictions.sqlRestriction("{alias}.data->'type'->'coding'->1->>'system' ilike '%"
											+ type.getValue() + "%'"),
									Restrictions.sqlRestriction("{alias}.data->'type'->'coding'->1->>'code' ilike '%"
											+ type.getValue() + "%'"),
									Restrictions.sqlRestriction("{alias}.data->'type'->'coding'->1->>'display' ilike '%"
											+ type.getValue() + "%'")
								);
					} else if (type.getMissing()) {
						criterion = Restrictions.or(Restrictions.sqlRestriction("{alias}.data->>'type' IS NULL"));
					} else if (!type.getMissing()) {
						criterion = Restrictions.or(Restrictions.sqlRestriction("{alias}.data->>'type' IS NOT NULL"));
					}
					disjunction.add(criterion);
				}
				criteria.add(disjunction);
			}
		}
	}

	
	

	/**
	 * This method builds criteria for DocumentReference category
	 * 
	 * @param theMap   : search parameter "category"
	 * @param criteria : for retrieving entities by composing Criterion objects
	 */
	private void buildCategoryCriteria(SearchParameterMap theMap, Criteria criteria) {
		List<List<? extends IQueryParameterType>> list = theMap.get("category");
		if (list != null) {
			for (List<? extends IQueryParameterType> values : list) {
				Disjunction disjunction = Restrictions.disjunction();
				for (IQueryParameterType params : values) {
					TokenParam category = (TokenParam) params;
					Criterion criterion = null;
					if (!category.isEmpty()) {
						criterion = Restrictions.or(Restrictions
								.sqlRestriction("{alias}.data->'category'->0->'coding'->0->>'system' ilike '%" + category.getValue() + "%'"),
								Restrictions
								.sqlRestriction("{alias}.data->'category'->0->'coding'->0->>'code' ilike '%" + category.getValue() + "%'"),
								Restrictions
								.sqlRestriction("{alias}.data->'category'->0->'coding'->0->>'display' ilike '%" + category.getValue() + "%'"),
								Restrictions
								.sqlRestriction("{alias}.data->'category'->0->'coding'->1->>'system' ilike '%" + category.getValue() + "%'"),
								Restrictions
								.sqlRestriction("{alias}.data->'category'->0->'coding'->1->>'code' ilike '%" + category.getValue() + "%'"),
								Restrictions
								.sqlRestriction("{alias}.data->'category'->0->'coding'->1->>'display' ilike '%" + category.getValue() + "%'")
								);
					} else if (category.getMissing()) {
						criterion = Restrictions.or(Restrictions.sqlRestriction("{alias}.data->>'category' IS NULL"));
					} else if (!category.getMissing()) {
						criterion = Restrictions
								.or(Restrictions.sqlRestriction("{alias}.data->>'category' IS NOT NULL"));
					}
					disjunction.add(criterion);
				}
				criteria.add(disjunction);
			}
		}
	}

	/**
	 * This method builds criteria for DocumentReference patient
	 * 
	 * @param theMap   : search parameter "patient"
	 * @param criteria : for retrieving entities by composing Criterion objects
	 */
	private void buildPatientCriteria(SearchParameterMap theMap, Criteria criteria) {
		List<List<? extends IQueryParameterType>> list = theMap.get("patient");
		if (list != null) {
			for (List<? extends IQueryParameterType> values : list) {
				Disjunction disjunction = Restrictions.disjunction();
				for (IQueryParameterType params : values) {
					ReferenceParam patient = (ReferenceParam) params;
					Criterion criterion = null;
					if (patient.getValue() != null) {
						criterion = Restrictions.or(
								Restrictions.sqlRestriction(
										"{alias}.data->'subject'->>'reference' ilike '%" + patient.getValue() + "%'"),
								Restrictions.sqlRestriction(
										"{alias}.data->'subject'->>'display' ilike '%" + patient.getValue() + "%'"));

					} else if (patient.getMissing()) {
						criterion = Restrictions.or(Restrictions.sqlRestriction("{alias}.data->>'subject' IS NULL"));

					} else if (!patient.getMissing()) {
						criterion = Restrictions
								.or(Restrictions.sqlRestriction("{alias}.data->>'subject' IS NOT NULL"));

					}
					disjunction.add(criterion);
				}
				criteria.add(disjunction);
			}
		}
	}

	

	/**
	 * This method builds criteria for DocumentReference date
	 * 
	 * @param theMap   : search parameter "date"
	 * @param criteria : for retrieving entities by composing Criterion objects
	 */
	private void buildDateCriteria(SearchParameterMap theMap, Criteria criteria) {
		List<List<? extends IQueryParameterType>> list = theMap.get("date");
		if (list != null) {
			for (List<? extends IQueryParameterType> values : list) {
				for (IQueryParameterType params : values) {
					DateParam date = (DateParam) params;
					String dateFormat = date.getValueAsString();
					if (date.getPrefix() != null) {
						if (date.getPrefix().getValue() == "gt") {
							criteria.add(Restrictions
									.sqlRestriction("{alias}.data->>'date' > '" + dateFormat + "'"));
						} else if (date.getPrefix().getValue() == "lt") {
							criteria.add(Restrictions
									.sqlRestriction("{alias}.data->>'date' < '" + dateFormat + "'"));
						} else if (date.getPrefix().getValue() == "ge") {
							criteria.add(Restrictions
									.sqlRestriction("{alias}.data->>'date' >= '" + dateFormat + "'"));
						} else if (date.getPrefix().getValue() == "le") {
							criteria.add(Restrictions
									.sqlRestriction("{alias}.data->>'date' <= '" + dateFormat + "'"));
						} else {
							criteria.add(Restrictions
									.sqlRestriction("{alias}.data->>'date' = '" + dateFormat + "'"));
						}
					}
				}
			}
		}
	}

	/**
	 * This method builds criteria for DocumentReference id
	 * 
	 * @param theMap   : search parameter "_id"
	 * @param criteria : for retrieving entities by composing Criterion objects
	 */
	private void buildIdCriteria(SearchParameterMap theMap, Criteria criteria) {
		List<List<? extends IQueryParameterType>> list = theMap.get("_id");
		if (list != null) {
			for (List<? extends IQueryParameterType> values : list) {
				for (IQueryParameterType params : values) {
					StringParam id = (StringParam) params;
					if (id.getValue() != null) {
						criteria.add(Restrictions.sqlRestriction("{alias}.data->>'id' = '" + id.getValue() + "'"));

					}
				}
			}
		}
	}

	/**
	 * This method builds criteria for DocumentReference identifier
	 * 
	 * @param theMap   : search parameter "identifier"
	 * @param criteria : for retrieving entities by composing Criterion objects
	 */
	private void buildIdentifierCriteria(SearchParameterMap theMap, Criteria criteria) {
		List<List<? extends IQueryParameterType>> list = theMap.get("identifier");

		if (list != null) {
			for (List<? extends IQueryParameterType> values : list) {
				Disjunction disjunction = Restrictions.disjunction();
				for (IQueryParameterType params : values) {
					TokenParam identifier = (TokenParam) params;
					Criterion orCond = null;
					if (identifier.getValue() != null) {
						orCond = Restrictions.or(
								Restrictions.sqlRestriction("{alias}.data->'identifier'->0->>'value' ilike '%"
										+ identifier.getValue() + "%'"),
								Restrictions.sqlRestriction("{alias}.data->'identifier'->1->>'value' ilike '%"
										+ identifier.getValue() + "%'"),
								
								Restrictions.sqlRestriction("{alias}.data->'identifier'->0->>'system' ilike '%"
										+ identifier.getValue() + "%'"),
								Restrictions.sqlRestriction("{alias}.data->'identifier'->1->>'system' ilike '%"
										+ identifier.getValue() + "%'")
								);
					}
					disjunction.add(orCond);
				}
				criteria.add(disjunction);
			}
		}
	}

	@Override
	@Transactional(value=TxType.REQUIRES_NEW)
	public DafDocumentReference createDocumentReference(DocumentReference theDocumentReference) {
		DafDocumentReference dafDocumentReference = new DafDocumentReference();
		IParser jsonParser = fhirContext.newJsonParser();
		jsonParser.encodeResourceToString(theDocumentReference);
		dafDocumentReference.setData(jsonParser.encodeResourceToString(theDocumentReference));
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(dafDocumentReference);
		session.getTransaction().commit();
		session.close();
		return dafDocumentReference;
	}
	
	 /**
     * This method builds criteria for updating DocumentReference 
     * by id
     * 
     * @param theId
     * @param theDocumentReference
     * @return
     */
	public DafDocumentReference updateDocumentReferenceById(int theId, DocumentReference theDocumentReference) {
		DafDocumentReference dafDocumentReference = new DafDocumentReference();
		IParser jsonParser = fhirContext.newJsonParser();
		dafDocumentReference.setId(theId);
		dafDocumentReference.setData(jsonParser.encodeResourceToString(theDocumentReference));
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.update(dafDocumentReference);
		session.getTransaction().commit();
		session.close();
		return dafDocumentReference;
	}
	
	@SuppressWarnings({"unchecked", "deprecation"})
	public List<DafDocumentReference> getDocumentReferenceForPatientsBulkData(String patientId, Date start, Date end) {
       	
		Criteria criteria = getSession().createCriteria(DafDocumentReference.class, "docRef");
		if(patientId != null) {
			criteria.add(Restrictions.sqlRestriction("{alias}.data->'subject'->>'reference' = 'Patient/"+patientId+"'"));
		}
		if(start != null) {
			criteria.add(Restrictions.ge("timestamp", start));
		}
		if(end != null) {
			criteria.add(Restrictions.le("timestamp", end));
		}
    	return criteria.list();
    }
	
	@SuppressWarnings({"unchecked", "deprecation"})
	public List<DafDocumentReference> getDocumentReferenceForBulkData(Date start, Date end) {
       	
		Criteria criteria = getSession().createCriteria(DafDocumentReference.class, "docRef");
        criteria.add(Restrictions.sqlRestriction("{alias}.data->>'subject' IS NOT NULL"));
		
		if(start != null) {
			criteria.add(Restrictions.ge("timestamp", start));
		}
		if(end != null) {
			criteria.add(Restrictions.le("timestamp", end));
		}
    	return criteria.list();
    }
}