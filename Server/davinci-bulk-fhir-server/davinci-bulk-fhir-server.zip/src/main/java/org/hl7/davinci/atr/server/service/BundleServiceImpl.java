package org.hl7.davinci.atr.server.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hl7.davinci.atr.server.dao.PatientDao;
import org.hl7.davinci.atr.server.dao.PractitionerDao;
import org.hl7.davinci.atr.server.model.DafBundle;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Bundle.BundleEntryComponent;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ca.uhn.fhir.rest.server.exceptions.UnprocessableEntityException;

@Service("bundleService")
@Transactional
public class BundleServiceImpl implements BundleService {
	private static final Logger logger = LoggerFactory.getLogger(BundleServiceImpl.class);    

	@Autowired
    private PatientDao patientDao;
	@Autowired
    private PractitionerDao practitionerDao;
	@Override
	public DafBundle createBundle(Bundle theBundle) {
		ArrayList<String> practitionersList = new ArrayList<>();
		try {
			if(theBundle != null && !theBundle.isEmpty()) {
				if(theBundle.hasEntry() && !theBundle.getEntry().isEmpty()) {
					List<BundleEntryComponent> bundleEntryComponentList = theBundle.getEntry();
					if(bundleEntryComponentList != null && !bundleEntryComponentList.isEmpty()) {
						for(BundleEntryComponent component:bundleEntryComponentList) {
							if(component.hasResource()){
								String resourceName = component.getResource().getResourceType().name();
								if(resourceName.equalsIgnoreCase("Practitioner")) {
									practitionersList.add(component.getResource().getIdElement().getIdPart());
								}
							}
						}
						logger.info(" List of practitioners : "+practitionersList);
						for(BundleEntryComponent bundleComponent:bundleEntryComponentList) {
							if(bundleComponent.hasResource()){
								String resourceName = bundleComponent.getResource().getResourceType().name();
								if(resourceName.equalsIgnoreCase("Patient")) {
									Patient thePatient = (Patient) bundleComponent.getResource();
									if(thePatient.hasGeneralPractitioner()) {
										List<Reference> referenceList = new ArrayList<>();
										referenceList = thePatient.getGeneralPractitioner();
										for( Reference reference:referenceList) {
											if(reference.hasReference()) {
												String referenceId = reference.getReferenceElement().getIdPart();
												String referenceResource = reference.getReferenceElement().getResourceType();
												if(referenceResource.equalsIgnoreCase("Practitioner") && practitionersList != null) {
													boolean isIdPresent = practitionersList.contains(referenceId);
													if(isIdPresent) {
														patientDao.createPatient(thePatient);
														logger.info("Patient referenced practitioner found. Hence Patient.id "+thePatient.getIdElement().getIdPart()+" is saved.");
													}
													else {
														logger.info("Practitioner:: {} not found. Hence Patient {} is not saved.",referenceId,thePatient.getIdElement().getIdPart());
														throw new UnprocessableEntityException("Practitioner:: {} not found. Hence Patient {} is not saved.",referenceId,thePatient.getIdElement().getIdPart());
													}
												}
											} 
										}
									}
									else {
										patientDao.createPatient(thePatient);
										logger.info(" Patient saved. No Practitioner reference found ");
									}
								}
								else if(resourceName.equalsIgnoreCase("Practitioner")) {
									Practitioner thePractitioner = (Practitioner) bundleComponent.getResource();
									practitionerDao.createPractitioner(thePractitioner);
									logger.info(" Practitioner saved ");
								}
							}
						}
					}
				} else {
					throw new UnprocessableEntityException("Bundle doesn't contain any Entries to process");
				}
			}
		}
		catch(Exception e) {
			logger.error("Exception in createBundle of BundleServiceImpl ", e);
		}
		return null;
	}
}
